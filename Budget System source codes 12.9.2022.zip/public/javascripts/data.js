
const ROLE = {
    ADMIN: 'ADMIN',
    PO: 'PO',
    PUH: 'PUH',
    BM: 'BM',
    AM: 'AM',
    RD: 'RD',
    DED: 'DED'
  }

  module.exports = { ROLE }
